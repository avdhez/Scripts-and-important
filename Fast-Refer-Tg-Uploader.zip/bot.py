import asyncio
import aiohttp
import os
import re
import time
import mimetypes
import shutil
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup  # FIXED: Correct import
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, ContextTypes, filters
from telegram.constants import ParseMode
import tempfile
from urllib.parse import urlparse
import logging

# Configure logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Bot configuration
BOT_TOKEN = "8335985088:AAFt-pTSHrzplombguBvC19b5U5jfGQ1HGo"

# User preferences storage
user_preferences = {}

# Create a custom temp directory with more space
CUSTOM_TEMP_DIR = os.path.join(os.path.expanduser("~"), "telegram_bot_temp")
os.makedirs(CUSTOM_TEMP_DIR, exist_ok=True)

class LightningDownloader:
    def __init__(self):
        self.chunk_size = 65536
        self.session = None
        self.temp_dir = CUSTOM_TEMP_DIR
        
    async def get_session(self):
        """Get or create aiohttp session"""
        if self.session is None:
            timeout = aiohttp.ClientTimeout(total=3600)
            connector = aiohttp.TCPConnector(limit=100, limit_per_host=10)
            self.session = aiohttp.ClientSession(
                timeout=timeout, 
                connector=connector,
                headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}
            )
        return self.session
        
    async def download_file(self, url, referer=None, progress_callback=None):
        """Download file with custom temp directory"""
        session = await self.get_session()
        
        headers = {}
        if referer:
            headers['Referer'] = referer
            
        try:
            async with session.get(url, headers=headers) as response:
                if response.status != 200:
                    raise Exception(f"HTTP {response.status}: {response.reason}")
                
                total_size = int(response.headers.get('content-length', 0))
                
                # Check available space
                if not self.has_enough_space(total_size):
                    raise Exception("Not enough disk space available")
                
                # Get filename and content type
                filename = self.get_filename(url, response)
                content_type = response.headers.get('content-type', '')
                filename = self.shorten_filename(filename)
                
                # Create temporary file in custom directory
                temp_file = tempfile.NamedTemporaryFile(
                    delete=False, 
                    suffix=os.path.splitext(filename)[1],
                    dir=self.temp_dir
                )
                
                downloaded = 0
                last_update_time = 0
                start_time = time.time()
                
                async for chunk in response.content.iter_chunked(self.chunk_size):
                    if chunk:
                        temp_file.write(chunk)
                        downloaded += len(chunk)
                        
                        # Update progress only every 5 seconds
                        current_time = time.time()
                        if (current_time - last_update_time >= 5) or (downloaded == total_size):
                            if progress_callback and total_size > 0:
                                percentage = (downloaded / total_size) * 100
                                speed = downloaded / (current_time - start_time)
                                await progress_callback(percentage, downloaded, total_size, speed)
                                last_update_time = current_time
                    
                temp_file.close()
                
                return {
                    'success': True,
                    'file_path': temp_file.name,
                    'filename': filename,
                    'file_size': downloaded,
                    'content_type': content_type
                }
                
        except Exception as e:
            logger.error(f"Download error: {e}")
            return {'success': False, 'error': str(e)}
    
    def has_enough_space(self, required_size):
        """Check if there's enough disk space"""
        try:
            # Get available space in custom temp directory
            statvfs = os.statvfs(self.temp_dir)
            free_space = statvfs.f_frsize * statvfs.f_bavail
            
            # Require at least 10% more space than needed
            return free_space > (required_size * 1.1)
        except:
            # If we can't check, assume there's enough space
            return True
    
    def get_filename(self, url, response):
        """Extract filename from URL or headers"""
        # Try Content-Disposition header first
        content_disposition = response.headers.get('Content-Disposition', '')
        if content_disposition:
            filename_match = re.findall('filename="?(.+)"?', content_disposition)
            if filename_match:
                return filename_match[0]
        
        # Extract from URL
        parsed_url = urlparse(url)
        path = parsed_url.path
        if path and '/' in path:
            filename = path.split('/')[-1]
            if filename and '.' in filename:
                return filename
        
        # Default filename with timestamp
        return f"download_{int(time.time())}.bin"
    
    def shorten_filename(self, filename, max_length=60):
        """Shorten filename if too long"""
        if len(filename) <= max_length:
            return filename
            
        name, ext = os.path.splitext(filename)
        max_name_length = max_length - len(ext) - 3
        
        if max_name_length <= 10:
            return filename[:max_length-3] + "..." + ext
            
        keep_from_start = max_name_length // 2
        keep_from_end = max_name_length - keep_from_start
        
        return name[:keep_from_start] + "..." + name[-keep_from_end:] + ext

    async def cleanup_old_files(self):
        """Clean up old temporary files"""
        try:
            current_time = time.time()
            for filename in os.listdir(self.temp_dir):
                file_path = os.path.join(self.temp_dir, filename)
                if os.path.isfile(file_path):
                    # Delete files older than 1 hour
                    if current_time - os.path.getctime(file_path) > 3600:
                        try:
                            os.unlink(file_path)
                            logger.info(f"Cleaned up old file: {filename}")
                        except:
                            pass
        except Exception as e:
            logger.error(f"Cleanup error: {e}")

    async def close(self):
        """Close the session"""
        if self.session:
            await self.session.close()

# Initialize downloader
downloader = LightningDownloader()

def is_video_file(filename, content_type=None):
    """Check if file is a video based on extension and content type"""
    video_extensions = {
        '.mp4', '.avi', '.mov', '.mkv', '.webm', '.flv', '.wmv', '.m4v', '.3gp', 
        '.mpg', '.mpeg', '.ts', '.mts', '.m2ts', '.vob', '.ogv', '.ogg', '.drc',
        '.gifv', '.m4v', '.svi', '.3gpp', '.3g2', '.mxf', '.roq', '.nsv', '.f4v',
        '.f4p', '.f4a', '.f4b'
    }
    
    video_content_types = {
        'video/mp4', 'video/avi', 'video/quicktime', 'video/x-msvideo', 
        'video/x-matroska', 'video/webm', 'video/x-flv', 'video/x-ms-wmv',
        'video/3gpp', 'video/mpeg', 'video/ogg', 'video/x-m4v'
    }
    
    # Check file extension
    file_ext = os.path.splitext(filename.lower())[1]
    if file_ext in video_extensions:
        return True
    
    # Check content type
    if content_type and any(video_type in content_type.lower() for video_type in video_content_types):
        return True
    
    return False

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Send welcome message"""
    # Clean up old files on start
    await downloader.cleanup_old_files()
    
    keyboard = [
        [InlineKeyboardButton("📥 Download File", callback_data="download_help")],
        [InlineKeyboardButton("⚙️ Settings", callback_data="settings")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        "⚡ **Lightning-Fast File Download Bot**\n\n"
        "Send me any direct download link and I'll download it at maximum speed!\n\n"
        "**Features:**\n"
        "• Ultra-fast downloads\n" 
        "• Files up to 2GB supported\n"
        "• Custom referer support\n"
        "• Smart progress updates\n"
        "• Document/Video format options",
        reply_markup=reply_markup,
        parse_mode=ParseMode.MARKDOWN
    )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show help message"""
    text = (
        "🚀 **Quick Start:**\n"
        "1. Send any direct download link\n"
        "2. Choose format\n"
        "3. Download starts immediately\n\n"
        
        "⚙️ **Commands:**\n"
        "/setreferer - Set custom referer\n"
        "/format - Set default format\n"
        "/help - Show this message\n\n"
        
        "💡 **Format Options:**\n"
        "• **Document**: Always sends as file\n"
        "• **Video**: Sends as video if file is video format\n"
        "• **Auto**: Automatically detects file type\n\n"
        
        "📝 **Note:** Video format only works for actual video files"
    )
    await update.message.reply_text(text, parse_mode=ParseMode.MARKDOWN)

async def set_referer(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Set custom referer"""
    user_id = update.effective_user.id
    user_preferences.setdefault(user_id, {})
    
    if context.args:
        referer = ' '.join(context.args)
        if referer.lower() == 'remove':
            user_preferences[user_id].pop('referer', None)
            await update.message.reply_text("✅ Referer removed")
        else:
            user_preferences[user_id]['referer'] = referer
            await update.message.reply_text(f"✅ Referer set to: `{referer}`", parse_mode=ParseMode.MARKDOWN)
    else:
        await update.message.reply_text(
            "🔗 **Set Custom Referer**\n\n"
            "Usage: `/setreferer https://example.com`\n\n"
            "To remove referer: `/setreferer remove`",
            parse_mode=ParseMode.MARKDOWN
        )

async def set_format(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Set default file format"""
    keyboard = [
        [InlineKeyboardButton("📄 Document", callback_data="set_format_document")],
        [InlineKeyboardButton("🎥 Video", callback_data="set_format_video")],
        [InlineKeyboardButton("🤖 Auto Detect", callback_data="set_format_auto")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        "📁 **Choose Default Format:**\n\n"
        "• **Document**: Always send as file\n"
        "• **Video**: Send as video if possible\n"
        "• **Auto**: Automatically detect file type",
        reply_markup=reply_markup
    )

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle incoming messages"""
    text = update.message.text.strip()
    
    if text.startswith(('http://', 'https://')):
        await process_download_request(update, context, text)
    else:
        await update.message.reply_text("❌ Please send a valid HTTP/HTTPS URL")

async def process_download_request(update: Update, context: ContextTypes.DEFAULT_TYPE, url: str):
    """Process download request"""
    user_id = update.effective_user.id
    preferences = user_preferences.get(user_id, {})
    
    # Check if format is set
    if preferences.get('format'):
        await start_download(update, context, url, preferences.get('format'), preferences.get('referer'))
    else:
        # Ask for format
        keyboard = [
            [InlineKeyboardButton("📄 Document", callback_data=f"dl_doc_{hash(url)}")],
            [InlineKeyboardButton("🎥 Video", callback_data=f"dl_vid_{hash(url)}")],
            [InlineKeyboardButton("🤖 Auto", callback_data=f"dl_auto_{hash(url)}")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text("📁 **Choose how to send the file:**", reply_markup=reply_markup)
        context.user_data['pending_url'] = url

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle button callbacks"""
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    data = query.data
    
    if data == "download_help":
        await help_command(update, context)
    elif data == "settings":
        await show_settings(update, context)
    elif data.startswith("set_format_"):
        format_type = data.split("_")[2]
        user_preferences.setdefault(user_id, {})['format'] = format_type
        
        format_names = {
            'document': '📄 Document',
            'video': '🎥 Video', 
            'auto': '🤖 Auto Detect'
        }
        
        await query.edit_message_text(f"✅ Default format set to: **{format_names[format_type]}**", parse_mode=ParseMode.MARKDOWN)
    elif data.startswith("dl_"):
        parts = data.split("_")
        format_type = parts[1]  # doc, vid, or auto
        url = context.user_data.get('pending_url')
        
        if url:
            preferences = user_preferences.get(user_id, {})
            await query.edit_message_text("⚡ Starting download...")
            
            # Map short format to full format names
            format_map = {
                'doc': 'document',
                'vid': 'video',
                'auto': 'auto'
            }
            
            await start_download(update, context, url, format_map[format_type], preferences.get('referer'))

async def show_settings(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show user settings"""
    user_id = update.effective_user.id
    preferences = user_preferences.get(user_id, {})
    
    format_names = {
        'document': '📄 Document',
        'video': '🎥 Video',
        'auto': '🤖 Auto Detect'
    }
    
    format_display = format_names.get(preferences.get('format'), 'Not set')
    referer_display = preferences.get('referer', 'Not set')
    
    settings_text = (
        f"⚙️ **Your Settings:**\n\n"
        f"**Format:** {format_display}\n"
        f"**Referer:** `{referer_display}`\n\n"
        "Use /format to change format\n"
        "Use /setreferer to change referer"
    )
    
    await update.callback_query.edit_message_text(settings_text, parse_mode=ParseMode.MARKDOWN)

async def start_download(update: Update, context: ContextTypes.DEFAULT_TYPE, url: str, format_type: str, referer: str = None):
    """Start the download process with proper format handling"""
    try:
        if update.callback_query:
            chat_id = update.callback_query.message.chat_id
            message_id = update.callback_query.message.message_id
        else:
            chat_id = update.message.chat_id
            message_id = update.message.message_id
        
        # Send initial progress message
        progress_msg = await context.bot.send_message(
            chat_id, 
            "⚡ **Starting download...**", 
            parse_mode=ParseMode.MARKDOWN
        )
        
        # Track progress update times
        last_progress_time = 0
        
        async def progress_callback(percentage, downloaded, total, speed):
            nonlocal last_progress_time
            current_time = time.time()
            
            if (current_time - last_progress_time >= 5) or (percentage >= 100):
                progress_text = await format_progress_text(percentage, downloaded, total, speed, "Downloading")
                await context.bot.edit_message_text(
                    progress_text,
                    chat_id,
                    progress_msg.message_id,
                    parse_mode=ParseMode.MARKDOWN
                )
                last_progress_time = current_time
        
        # Download file
        result = await downloader.download_file(url, referer, progress_callback)
        
        if not result['success']:
            await context.bot.edit_message_text(
                f"❌ **Download Failed**\n`{result['error']}`",
                chat_id,
                progress_msg.message_id,
                parse_mode=ParseMode.MARKDOWN
            )
            return
        
        # Upload to Telegram
        file_path = result['file_path']
        filename = result['filename']
        content_type = result['content_type']
        
        try:
            await context.bot.edit_message_text(
                "📤 **Uploading to Telegram...**",
                chat_id,
                progress_msg.message_id,
                parse_mode=ParseMode.MARKDOWN
            )
            
            # Determine final format to use
            final_format = format_type
            if format_type == 'auto':
                # Auto-detect based on file type
                if is_video_file(filename, content_type):
                    final_format = 'video'
                else:
                    final_format = 'document'
            
            # Send file based on final format
            with open(file_path, 'rb') as file:
                if final_format == 'video' and is_video_file(filename, content_type):
                    # Send as video
                    await context.bot.send_video(
                        chat_id,
                        video=file,
                        filename=filename,
                        caption=f"🎥 {filename}",
                        read_timeout=300,
                        write_timeout=300,
                        connect_timeout=300,
                        supports_streaming=True
                    )
                else:
                    # Send as document
                    await context.bot.send_document(
                        chat_id,
                        document=file,
                        filename=filename,
                        caption=f"📄 {filename}",
                        read_timeout=300,
                        write_timeout=300,
                        connect_timeout=300
                    )
            
            # Delete progress message on success
            await context.bot.delete_message(chat_id, progress_msg.message_id)
            
        except Exception as upload_error:
            logger.error(f"Upload error: {upload_error}")
            
            # If video upload fails, try as document
            if "video" in str(upload_error).lower():
                try:
                    with open(file_path, 'rb') as file:
                        await context.bot.send_document(
                            chat_id,
                            document=file,
                            filename=filename,
                            caption=f"📄 {filename} (sent as document)",
                            read_timeout=300,
                            write_timeout=300,
                            connect_timeout=300
                        )
                    await context.bot.delete_message(chat_id, progress_msg.message_id)
                except Exception as doc_error:
                    await context.bot.edit_message_text(
                        f"❌ **Upload Failed**\n`{doc_error}`",
                        chat_id,
                        progress_msg.message_id,
                        parse_mode=ParseMode.MARKDOWN
                    )
            else:
                await context.bot.edit_message_text(
                    f"❌ **Upload Failed**\n`{upload_error}`",
                    chat_id,
                    progress_msg.message_id,
                    parse_mode=ParseMode.MARKDOWN
                )
        finally:
            # Clean up temporary file
            try:
                if os.path.exists(file_path):
                    os.unlink(file_path)
                    logger.info(f"Cleaned up: {file_path}")
            except Exception as cleanup_error:
                logger.error(f"Cleanup error: {cleanup_error}")
                
    except Exception as e:
        logger.error(f"Error in download process: {e}")
        error_msg = f"❌ **Error**: `{str(e)[:100]}...`"
        try:
            await context.bot.edit_message_text(
                error_msg, 
                chat_id, 
                progress_msg.message_id, 
                parse_mode=ParseMode.MARKDOWN
            )
        except:
            await context.bot.send_message(chat_id, error_msg, parse_mode=ParseMode.MARKDOWN)

async def format_progress_text(percentage, downloaded, total, speed, action):
    """Format progress text with speed information"""
    bars = "█" * int(percentage / 10) + "░" * (10 - int(percentage / 10))
    
    def format_size(size):
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size < 1024.0:
                return f"{size:.1f} {unit}"
            size /= 1024.0
        return f"{size:.1f} TB"
    
    speed_mb = speed / 1024 / 1024
    speed_text = f"{speed_mb:.1f} MB/s" if speed_mb >= 1 else f"{speed/1024:.1f} KB/s"
    
    progress_text = (
        f"⚡ **{action}...**\n"
        f"`[{bars}] {percentage:.1f}%`\n"
        f"`{format_size(downloaded)} / {format_size(total)}`\n"
        f"`Speed: {speed_text}`"
    )
    
    return progress_text

def check_disk_space():
    """Check available disk space"""
    try:
        statvfs = os.statvfs(CUSTOM_TEMP_DIR)
        free_gb = (statvfs.f_frsize * statvfs.f_bavail) / (1024 ** 3)
        total_gb = (statvfs.f_frsize * statvfs.f_blocks) / (1024 ** 3)
        logger.info(f"Disk space - Free: {free_gb:.1f}GB, Total: {total_gb:.1f}GB")
        return free_gb
    except Exception as e:
        logger.error(f"Disk space check failed: {e}")
        return 0

def main():
    """Start the bot"""
    # Check disk space on startup
    free_space = check_disk_space()
    if free_space < 1:  # Less than 1GB free
        logger.warning(f"Low disk space: {free_space:.1f}GB free")
    
    application = Application.builder().token(BOT_TOKEN).build()
    
    # Add handlers
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("setreferer", set_referer))
    application.add_handler(CommandHandler("format", set_format))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    application.add_handler(CallbackQueryHandler(button_handler))
    
    print("⚡ Lightning Bot is running... Press Ctrl+C to stop")
    print(f"📁 Using temp directory: {CUSTOM_TEMP_DIR}")
    print(f"💾 Free space: {free_space:.1f}GB")
    
    try:
        application.run_polling()
    except KeyboardInterrupt:
        print("\n🛑 Bot stopped by user")
    finally:
        asyncio.run(downloader.close())

if __name__ == "__main__":
    main()