import subprocess
import sys

try:
    # Install requirements
    print("Installing requirements from requirements.txt...")
    subprocess.run([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"], check=True)
    
    # Run the bot
    print("Starting bot.py...")
    subprocess.run([sys.executable, "bot.py"], check=True)
    
except subprocess.CalledProcessError as e:
    print(f"Error occurred: {e}")
    sys.exit(1)
except FileNotFoundError:
    print("Error: requirements.txt or bot.py not found")
    sys.exit(1)